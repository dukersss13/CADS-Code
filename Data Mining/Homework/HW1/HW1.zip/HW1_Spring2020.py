#!/usr/bin/env python
# coding: utf-8

# ## Simple Linear Regression_Ordinary Least Squares (OLS)
# 

# #### Q1 (2 points)  
# In these exercises we'll be working with simple linear regression. Simple linear regression is an approach for predicting a response using only a single feature.
# 
# To create our model, we must “learn” or estimate the values of the regression coefficients $\hat{\beta}0$ and $\hat{\beta}1$. Once we’ve estimated these coefficients, we can use the model to predict responses. Here we are going to use the Least Squares technique as the cost function to estimate the coefficients.
# 

# In[168]:


import numpy as np 
def estimate_coef_OLS(X, y): 
    # x: np array of input with size n
    # y: np array of response/output with size n
    # return(B0, B1)
    ### YOUR CODE HERE ###
                # calculating regression coefficients(B0,B1)
    ybar = np.mean(y)
    xbar = np.mean(X)
    
    
    B1 = (np.sum((y - ybar)*(X - xbar)))/(np.sum((X - xbar)**2))
    B0 = ybar - B1*xbar

    return(B0, B1) 


# #### Q2 (4 points)  
# Scikit-learn includes a number of dataset simulation functions, one of which is "make_regression ()". Importantly, we can create a dataset for regression that has both informative features and uninformative features, this makes for a good exercise in model selection.

# In[169]:


import numpy as np 
from sklearn import linear_model, datasets
n_samples = 100
n_outliers = 5
X, y, coef = datasets.make_regression(n_samples=n_samples, n_features=1,
                                      n_informative=1, noise=10,
                                      coef=True, random_state=2)
# Add outlier data
np.random.seed(1)
X[:n_outliers] = 15 + 0.7 * np.random.normal(size=(n_outliers, 1))


#  a) Plot the data (X and y)
#  
#  b) Use your code from the previous part to find the linear model for this dataset.

# In[170]:


from matplotlib import pyplot as plt
plt.style.use('fivethirtyeight')
get_ipython().run_line_magic('matplotlib', 'inline')

### YOUR CODE HERE ###
# use scatter plot to represent the dataset
plt.scatter(X,y)

# Plot the linear regression model that you found from Q1

xbar = np.mean(X)
ybar = np.mean(y)

B0,B1 = estimate_coef_OLS(X,y)
y2 = B1*X + B0
plt.plot(X,y2,color = 'r')

##The regression line is not correct because it is trying to include the 5 outliers.


# c) Try to find the outliers in this dataset, 
# Then remove the outliers and find a new linear model for the remained data(without outliers)

# In[171]:


dev = np.std(X) ## We can identify the outliers by checking to see which points are farther than 2 intervals of std.

for index, i in enumerate(X): #This loop returns the indecies of the outliers in column vector X.
    if abs(i-xbar) >= 2*dev:
        print(index,i)

i = 0    #Since the outliers are the first 5 points, this while loop will eliminate the 5 first data points in X & y.
while i <=4:
    X = np.delete(X, 0)
    i += 1

i = 0
while i <=4:
    y = np.delete(y, 0)
    i += 1

B0,B1= estimate_coef_OLS(X, y)

y2 = B0 + B1*X

plt.scatter(X,y,color='b')
plt.plot(X,y2,color='r')


# d) Use Statsmodel and Scikit-learn (OLS) and compare the result with part (c).

# In[172]:


### YOUR CODE HERE ###

#Using Statsmodels
import statsmodels.api as sm
s = sm.add_constant(X) #Adding vector X into the statsmodels function
results = sm.OLS(y,s).fit()
print(results.summary())

#Using Scikit-learn
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

X_df = pd.DataFrame({'X':X})
reg = LinearRegression().fit(X_df,y)
reg.score(X_df,y)


# #### Q3 (4 points)
# Kaggle is a competition platform for data scientists. In this class you will learn how to use the platform to practice data-science skills and "compete" with your classmates.

# a) Reigster an account on [kaggle.com](https://www.kaggle.com) if you don't have one yet. Type in your kaggle profile name in the following block.

# In[173]:


### What is your name on your Kaggle profile?
#Duc Le


# b) Use [this link](https://www.kaggle.com/t/58bf348e221f4a698c302663cd0e8f5e) to the competition page, and click on the top right button "Join Competition" to join the competition. The name of the competition is "Chapman CS530 Predicting Red Wine Quality". Copy the rules of the competition to the following block.

# In[174]:


### What is the rule of the competition?
#1. Download the training (train.csv) and testing set (test.csv) from the Data tab. We will talk much more about training and test sets in the course. Generally speaking, for the training set you have the information (the matrix X) and the labels (the vector y). But you do not have the labels for the test set. Here you have the wine rating for the training set but not the the test set. Therefore, your task is to fit a regression model based on the training set (where you are given the quality of the wine for each entry) and then predict as accuracy as possible on the quality of wines in the testing set, where you do not have the quality of the wine.

#2. This competition is designed for the "Regression, Resampling and Regularization Module" and it is part of the homework assignments. Submission closes on Sunday at 11:59pm.

#3. You are expected to submit your solutions to Kaggle and also your code on Canvas to get full credits.


# c) Download the necessary datasets, read the data into a pandas dataframe and run any necessary data preprocessing techniques to allow further analysis.

# In[175]:


### YOUR CODE for c) GOES HERE

train = pd.read_csv("train.csv", index_col = 0, sep = ',', header = 0)


# d) Choose one variable that you think might have the biggest effects on the quality of wine. Fit a single linear regression model to that variable using Statsmodel. Plot a scatter plot of the dependent variable over the independent variable and also plot the fitted line on the same plot to see how well your model fits. Also add the R<sup>2</sup> score as the title of the plot.

# In[176]:


### YOUR CODE for d) GOES HERE
#I CHOOSE ALCOHOL! More alcohol = good time :) 

alcy = train['alcohol']
quality = train['quality']
s2 = sm.add_constant(alcy)
guess = sm.OLS(quality,s2).fit()
print(guess.summary())


# In[177]:


#From the statsmodel table:
m = 0.5649 
b = -0.2477

#plt.scatter(alcy,quality, color = 'b')

alcy_dev = np.std(alcy)
qual_dev = np.std(quality)

mean_alcy = np.mean(alcy)
alcy2 = np.array([])

mean_quality = np.mean(quality)
quality2 = np.array([])

for i in alcy:
    if abs(i - mean_alcy) < 2*alcy_dev:
        alcy2 = np.append(alcy2,i)
        
for i in quality:
    if abs(i - mean_quality) < 2*qual_dev:
        quality2 = np.append(quality2, i)        

s3 = sm.add_constant(alcy2)
guess2 = sm.OLS(quality2,s3).fit()
print(guess2.summary())

#R-Squared score of the adjusted data w/o the outliers is 0.238.

m2 = 0.3670
b2 = 1.8123
q2 = m2*alcy2 + b2

plt.scatter(alcy2,quality2)
plt.plot(alcy2,q2,color = 'r')
plt.title("R Squared score is 0.238")


# e) Make predictions on the testing set using your model created in d), create a submission and submit it to kaggle. 

# In[178]:


### YOUR CODE for e) GOES HERE
test = pd.read_csv("test.csv", index_col = 0, sep = ',', header = 0)
t_alcy = test['alcohol']

#This function will predict the quality of the wine given the alcohol level.
m2 = 0.3670
b2 = 1.8123
def quality_test(t,m,b):
    q2 = m2*t + b2
    return q2
results = quality_test(t_alcy,m2,b2)
test['predicted'] = results


# In[179]:


### Report the score of your first submission on Kaggle here
#First submission score on Kaggle: 34.41873


# f) Try to fit the regression model using a different variable. Create another submission and submit it to kaggle. Discuss why that variable was better, worse, or roughly the same as the previous variable that you fit.

# In[186]:


### YOUR CODE for f) GOES HERE

dens = train['density']
quality = train['quality']
s1 = sm.add_constant(dens)
guess = sm.OLS(quality,s1).fit()
print(guess.summary())


# density vs. quality
m = 5.3872
b = 0.2666


# In[189]:


dens_dev = np.std(dens)
qual_dev = np.std(quality)

mean_dens = np.mean(dens)
dens2 = np.array([])

mean_quality = np.mean(quality)
quality2 = np.array([])

for i in dens:
    if abs(i - mean_dens) < 2*dens_dev:
        dens2 = np.append(dens2,i)
        
for i in quality:
    if abs(i - mean_quality) < 2*qual_dev:
        quality2 = np.append(quality2, i)        


snew = sm.add_constant(dens2)
guess_new = sm.OLS(quality2,snew).fit()
print(guess_new.summary())


#R-Squared score of the adjusted data w/o the outliers is 0.042.

m3 = -86.6117
b3 = 91.9691
q2 = m3*dens2 + b3

plt.scatter(dens2,quality2)
plt.plot(dens2,q2,color = 'r')
plt.title("R Squared score is 0.042")


# In[190]:


test_dens = test['density']
results2 = quality_test(test_dens,m3,b3)
test['predicted'] = results2


# In[183]:


### Report the score of your second submission on Kaggle here

#Second submission score is 50.39290. :/


# In[184]:


### Discussion Goes Here

# The linear regression model accomodate to the data much better once the outliers were removed. 
# The quality of the wine in my model seems to correlate more with the alcohol level than the density level.


# In[ ]:




